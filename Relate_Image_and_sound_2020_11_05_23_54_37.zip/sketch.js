let t1 = 0.1; // attack time in seconds
let l1 = 0.7; // attack level 0.0 to 1.0
let t2 = 0.3; // decay time in seconds
let l2 = 0.1; // decay level  0.0 to 1.0

let env;
let triOsc;

function setup() {
  let cnv = createCanvas(500, 500);
  cnv.mousePressed(playSound);
  triOsc = new p5.Oscillator('triangle');
  textSize(12);
  size = createSlider(1, 255, 100);
  size.position(10, 450);
  r = createSlider(1, 255, 100);
  r.position(10, 30);
  g = createSlider(1, 255, 100);
  g.position(350, 30);
}

function draw(){
 fill(r.value(),g.value(),0);
 background(220);
 ellipse(250, 250,size.value()); 
 rightText();
 setSound();
}

//Function for setting sound values
function setSound()
{
 t1=(r.value()/255);
 t2=(g.value()/255);
 l1=(size.value()/255);
 l2=(size.value()/255);
 env = new p5.Envelope(t1, l1, t2, l2);
}

//Function for playing Sound
function playSound() 
{
  triOsc.start();
  env.play(triOsc);
}

//Function for displaying Text on Screen
function rightText()
{
 fill(0);
 text('Circle Size/Sound Volume', 10, 450);
 text('Red/Attack Time', 10, 30);
 text('Green/Decay Time', 350, 30);
}